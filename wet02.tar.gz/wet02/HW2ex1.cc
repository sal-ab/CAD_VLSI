#include <errno.h>
#include <signal.h>
#include <sstream>
#include <fstream>
#include <algorithm>
#include <queue>
#include "hcm.h"
#include "flat.h"
#include "hcmvcd.h"
#include "hcmsigvec.h"
#include <set>
#include <unordered_map>

using namespace std;

//globals:
bool verbose = false;


// Enum for logic gate functions
enum GateType {
    OR, NOR, AND, NAND, INV, NOT, XOR, BUFFER, UNKNOWN
};






//Our Classes
class PCell;
class Net;
class Hash;

//Our Functions
GateType getGateType(const string& logic_type);
bool calcOutput(vector<Net*>* input_wires, string logic_type);
void process_events_and_gates(set<Net*>& event_queue, set<PCell*>& gate_queue);
void dff_func(const vector<PCell*>& FF_vec, set<Net*>& event_queue);
void initialize_connections(unordered_map<string, PCell, Hash>& inst_HT, 
                            unordered_map<string, Net, Hash>& Node_HT);
void build_hashTablesAndVectors(map<string, hcmNode*>& nodes_map,
                                 map<string, hcmInstance*>& inst_map,
                                 unordered_map<string, PCell, Hash>& inst_HT,
                                 unordered_map<string, Net, Hash>& Node_HT,
                                 vector<Net*>& Logic_Inputs,
                                 vector<Net*>& output_nets,
                                 set<Net*>& event_queue,
                                 set<PCell*>& gate_queue,
                                 vector<PCell*>& FF_vec,
                                 vector<Net*>& nets_vcd);



class Net {
public:
    std::string name;
    hcmNode* node;
	PCell* input;
    std::vector<PCell*> fanOut; 

	bool newVal;
    bool firstVal;


    Net() 
        : name(""), node(nullptr), input(nullptr), fanOut{}, newVal(false), firstVal(true) {}

    Net(const std::string& name, hcmNode* node, PCell* input, 
        const std::vector<PCell*> fanout, bool newVal, bool firstVal) 
        : name(name), node(node), input(input), fanOut(fanout), newVal(newVal), firstVal(firstVal) {}

    Net(const Net& other) 
        : name(other.name), node(other.node), input(other.input), fanOut(other.fanOut), 
          newVal(other.newVal), firstVal(other.firstVal) {}

    bool operator<(const Net& other) const {
        return this->name < other.name;
    }
};



class PCell {
public:
    std::string name;
	std::vector<Net*> inputNets;
    Net* outputNet;
    hcmInstance* inst;


    PCell() 
        : name(""), inputNets{}, outputNet(nullptr), inst(nullptr) {}

    PCell(const std::string& name, const std::vector<Net*>& inputVec, Net* output, hcmInstance* instance) 
        : name(name), inputNets(inputVec), outputNet(output), inst(instance) {}

    PCell(const PCell& other) 
        : name(other.name), inputNets(other.inputNets), outputNet(other.outputNet), inst(other.inst) {}
};




class Hash {
public:
    size_t operator()(const std::string& name) const {
        return std::hash<std::string>{}(name);
    }
};





// Helper function to map gate function name to enum
GateType getGateType(const string& logic_type) {
    size_t pos = logic_type.find_first_of("0123456789");
    string func_temp = logic_type.substr(0, pos);

    if (func_temp == "or") return OR;
    if (func_temp == "nor") return NOR;
    if (func_temp == "and") return AND;
    if (func_temp == "nand") return NAND;
    if (func_temp == "inv" || func_temp == "not") return INV;
    if (func_temp == "xor") return XOR;
    if (func_temp == "buffer") return BUFFER;
    
    return UNKNOWN;
}










//-------------------------------------------------------------------------------------------------------------------------------//

int main(int argc, char **argv) {
	int argIdx = 1;
	int anyErr = 0;
	unsigned int i;
	vector<string> vlgFiles;
	
	if (argc < 5) {
		anyErr++;
	} 
	else {
		if (!strcmp(argv[argIdx], "-v")) {
			argIdx++;
			verbose = true;
		}
		for (;argIdx < argc; argIdx++) {
			vlgFiles.push_back(argv[argIdx]);
		}
		
		if (vlgFiles.size() < 2) {
			cerr << "-E- At least top-level and single verilog file required for spec model" << endl;
			anyErr++;
		}
	}

	if (anyErr) {
		cerr << "Usage: " << argv[0] << "  [-v] top-cell signal_file.sig.txt vector_file.vec.txt file1.v [file2.v] ... \n";
		exit(1);
	}
 
	set< string> globalNodes;
	globalNodes.insert("VDD");
	globalNodes.insert("VSS");
	
	hcmDesign* design = new hcmDesign("design");
	string cellName = vlgFiles[0];
	for (i = 3; i < vlgFiles.size(); i++) {
		printf("-I- Parsing verilog %s ...\n", vlgFiles[i].c_str());
		if (!design->parseStructuralVerilog(vlgFiles[i].c_str())) {
			cerr << "-E- Could not parse: " << vlgFiles[i] << " aborting." << endl;
			exit(1);
		}
	}

	hcmCell *topCell = design->getCell(cellName);
	if (!topCell) {
		printf("-E- could not find cell %s\n", cellName.c_str());
		exit(1);
	}
	
	hcmCell *flatCell = hcmFlatten(cellName + string("_flat"), topCell, globalNodes);
	cout << "-I- Top cell flattened" << endl;

	string signalTextFile = vlgFiles[1];
	string vectorTextFile = vlgFiles[2];

	
	// Genarate the vcd file
	//-----------------------------------------------------------------------------------------//
	// If you need to debug internal nodes, set debug_mode to true in order to see in 
	// the vcd file and waves the internal nodes.
	// NOTICE !!!
	// you need to submit your work with debug_mode = false
	// vcdFormatter vcd(cellName + ".vcd", flatCell, globalNodes, true);  <--- for debug only!
	//-----------------------------------------------------------------------------------------//
	vcdFormatter vcd(cellName + ".vcd", flatCell, globalNodes);
	if(!vcd.good()) {
		printf("-E- vcd initialization error.\n");
		exit(1);
	}

	// initiate the time variable "time" to 1 
	int time = 1;
	hcmSigVec parser(signalTextFile, vectorTextFile, verbose);
	set<string> signals;
	parser.getSignals(signals);

	//-----------------------------------------------------//
	map<string, hcmNode*> nodes_map = flatCell->getNodes();
	map<string, hcmInstance*> inst_map = flatCell->getInstances();
	map<string, hcmNode*>::const_iterator it_n;
	map<string, hcmInstance*>::const_iterator it_g;
	
	set<Net*> event_queue; //for change in node values
	set<PCell*> gate_queue;// for change in instance output value
	
	vector<Net*> Logic_Inputs;//inputs
	vector<Net*> Logic_Outputs;//output
	
	unordered_map<string, PCell, Hash> inst_HT;//all instances
	unordered_map<string, Net, Hash> Node_HT;//all nodes


	vector<PCell*> FF_vec;
	vector<Net*> nets_vcd; 
	


	//build the hashtables
	build_hashTablesAndVectors(nodes_map, inst_map, inst_HT, Node_HT, 
								Logic_Inputs, Logic_Outputs, event_queue, gate_queue, 
								FF_vec, nets_vcd);
	



	//initializing the data sturcters with connections
	initialize_connections(inst_HT, Node_HT);
	

	hcmNode* node;
	list<const hcmInstance*> instances = {};

	// Deal with global nodes - VSS & VDD
	auto handle_global_node = [&](const string& node_name, bool value) {
		if (Node_HT.find(node_name) != Node_HT.end()) {
			Node_HT[node_name].newVal = value;
			event_queue.insert(&(Node_HT[node_name]));
		}
	};

	handle_global_node("VDD", true); // Set VDD to true
	handle_global_node("VSS", false); // Set VSS to false (default)
	// Reading each vector
	
	
	bool first_run = true;
	while (parser.readVector() == 0) {
		// Calculate DFF outputs

		dff_func(FF_vec, event_queue);
		
		
		
		// to make sure all outputs are correct at the start of each run when all FF outputs are 0, we don't add this to runtime
		if(first_run){
			// We place all sets in event queue
			for (auto& pair : Node_HT) {
				event_queue.insert(&pair.second); // Insert the address of the Net object
			}
			// We do a pre_simutation to make sure initial outputs are correct
			while (!event_queue.empty()) {
				process_events_and_gates(event_queue, gate_queue);
			}
			first_run = false;	
		}
		
		
		

		// Set the inputs to the values from the input vector.
		for (auto& input_net : Logic_Inputs) {
			bool new_value;
			bool old_value = input_net->newVal;
			parser.getSigValue(input_net->name, new_value);
	
			if (old_value != new_value || input_net->firstVal) {
				input_net->newVal = new_value;
				input_net->firstVal = false;
				event_queue.insert(input_net);
			}
		}

		// Simulate the vector (event-driven simulation)
		while (!event_queue.empty()) {
			process_events_and_gates(event_queue, gate_queue);
		}

		// Print inputs to VCD
		for (auto& net : nets_vcd) {
			node = net->node;
			hcmNodeCtx* nodeCtx = new hcmNodeCtx(instances, node);
			vcd.changeValue(nodeCtx, net->newVal);
			delete nodeCtx;
		}

		vcd.changeTime(time++);
	}

	//-----------------------------------------------------------------------------------------//
}	







void process_events_and_gates(set<Net*>& event_queue, set<PCell*>& gate_queue) {
    bool new_out;
    bool old_out;

    // Continue processing as long as there are events in the event queue
    while (!event_queue.empty()) {
        // Process the event queue and add corresponding gates to the gate queue
        for (auto& event : event_queue) {
            for (auto& fanOut : event->fanOut) {
                // Skip DFFs (Add only non-DFF primitive cells to the gate queue)
                if (fanOut->inst->masterCell()->getName() != "dff") {
                    gate_queue.insert(fanOut);
                }
            }
        }

        // Clear the event queue after processing
        event_queue.clear();

        // Process the gates in the gate queue
        for (auto& gate : gate_queue) {
            new_out = calcOutput(&(gate->inputNets), gate->inst->masterCell()->getName());
            old_out = gate->outputNet->newVal;

            // If output value has changed or it's the first value, update it
            if (old_out != new_out || gate->outputNet->firstVal) {
                gate->outputNet->newVal = new_out;
                gate->outputNet->firstVal = false;

                // If the output net has fanouts, insert them into the event queue
                if (!gate->outputNet->fanOut.empty()) {
                    event_queue.insert(gate->outputNet);
                }
            }
        }

        // Clear the gate queue after processing
        gate_queue.clear();
    }
}






// Function to calculate the output of a logic gate
bool calcOutput(vector<Net*>* input_wires, string logic_type) {
    // Extract the logic gate type
    GateType gateType = getGateType(logic_type);
    
    vector<bool> input_vals;
    for (Net* net : *input_wires) {
        input_vals.push_back(net->newVal);  // Push the 'newVal' from each Net
    }

    bool output = false;
    switch (gateType) {
        case OR:
            output = input_vals[0];
            for (size_t i = 1; i < input_vals.size(); ++i) {
                output = output || input_vals[i];
            }
            break;

        case NOR:
            output = input_vals[0];
            for (size_t i = 1; i < input_vals.size(); ++i) {
                output = output || input_vals[i];
            }
            output = !output;
            break;

        case AND:
            output = input_vals[0];
            for (size_t i = 1; i < input_vals.size(); ++i) {
                output = output && input_vals[i];
            }
            break;

        case NAND:
            output = input_vals[0];
            for (size_t i = 1; i < input_vals.size(); ++i) {
                output = output && input_vals[i];
            }
            output = !output;
            break;

        case INV:
        case NOT:
            output = !input_vals[0];
            break;

        case XOR:
            output = input_vals[0];
            for (size_t i = 1; i < input_vals.size(); ++i) {
                output = output ^ input_vals[i];
            }
            break;

        case BUFFER:
            output = input_vals[0];
            break;

        default:
            cout << "Didn't find the gate " << logic_type << endl;  // If gate name is not recognized
            break;
    }

    return output;
}






void dff_func(const vector<PCell*>& FF_vec, set<Net*>& event_queue) {
    // Iterate through the vector of DFF cells
    for (const auto& dff_cell : FF_vec) {
        bool sigCLK = false;
		bool Init_data = true;
        bool sigDATA = false;


        // Search for CLK and data signals in the input nets of the current DFF cell
        for (const auto& net : dff_cell->inputNets) {
            if (net->name != "CLK") {
                sigDATA = net->newVal;  // Update data signal
                Init_data = net->firstVal; // Update start data flag
            } else {
                sigCLK = net->newVal;  // Update clock signal
            }
        }

        // Combine both conditions into a single check
        if (sigCLK || Init_data) {
            // Skip updating if either the clock signal is high or start data is true
            continue;
        }

        // Update output value if sigDATA is different or it's the first value
        if (sigDATA != dff_cell->outputNet->newVal || dff_cell->outputNet->firstVal) {
            dff_cell->outputNet->newVal = sigDATA;
            dff_cell->outputNet->firstVal = false;
            // Insert the updated net into the event queue
            event_queue.insert(dff_cell->outputNet);
        }
    }
}

















void build_hashTablesAndVectors(map<string, hcmNode*>& nodes_map,
                                 map<string, hcmInstance*>& inst_map,
                                 unordered_map<string, PCell, Hash>& inst_HT,
                                 unordered_map<string, Net, Hash>& Node_HT,
                                 vector<Net*>& Logic_Inputs,
                                 vector<Net*>& Logic_Outputs,
                                 set<Net*>& event_queue,
                                 set<PCell*>& gate_queue,
                                 vector<PCell*>& FF_vec,
                                 vector<Net*>& nets_vcd) {
    // Process gates (instances) and populate inst_HT
    for (auto& it_g : inst_map) {
        vector<Net*> inputs;  // Inputs for the current gate
        inst_HT[it_g.second->getName()] = PCell(it_g.second->getName(), inputs, nullptr, it_g.second);

        // If the current gate is a DFF, add it to FF_vec
        if (it_g.second->masterCell()->getName() == "dff") {
            FF_vec.push_back(&inst_HT[it_g.second->getName()]);
        }
    }

    // Process nodes and populate Node_HT, Logic_Inputs, and Logic_Outputs
    for (auto& it_n : nodes_map) {
        if (it_n.second->getPort() != nullptr) { // Node has a global port
            vector<PCell*> fanout_gates;

            // Check if the port is an input or output
            if (it_n.second->getPort()->getDirection() == IN) {
                Node_HT[it_n.second->getPort()->getName()] = Net(it_n.second->getPort()->getName(),
                                                                        it_n.second,
                                                                        nullptr,
                                                                        fanout_gates, 
                                                                        false, 
                                                                        true);
                Logic_Inputs.push_back(&Node_HT[it_n.second->getPort()->getName()]);
            } else {
                Node_HT[it_n.second->getPort()->getName()] = Net(it_n.second->getPort()->getName(),
                                                                        it_n.second,
                                                                        nullptr,
                                                                        fanout_gates, 
                                                                        false, 
                                                                        true);
                Logic_Outputs.push_back(&Node_HT[it_n.second->getPort()->getName()]);
            }
            nets_vcd.push_back(&Node_HT[it_n.second->getPort()->getName()]);
        } else {
            // Node doesn't have a port (normal node)
            Node_HT[it_n.second->getName()] = Net(it_n.second->getName(),
                                                         it_n.second,
                                                         nullptr,
                                                         {}, // No fanout gates
                                                         false, 
                                                         true);
            nets_vcd.push_back(&Node_HT[it_n.second->getName()]);
        }
    }
}



void initialize_connections(unordered_map<string, PCell, Hash>& inst_HT, 
                            unordered_map<string, Net, Hash>& Node_HT) {
    
    // Helper function to initialize net for non-global nodes
    auto initialize_non_global_net = [&](hcmNode* curr_node, PCell* gate) {
        auto iter_net = Node_HT.find(curr_node->getName());
        if (iter_net != Node_HT.end()) {
            Node_HT[curr_node->getName()].fanOut.push_back(gate);
        } else {
            Node_HT[curr_node->getName()] = Net(curr_node->getName(), curr_node, nullptr, 
                                                       {gate}, false, true);
        }
    };

    // Helper function to initialize net for global nodes
    auto initialize_global_net = [&](hcmNode* curr_node, PCell* gate) {
        auto iter_net = Node_HT.find(curr_node->getPort()->getName());
        if (iter_net != Node_HT.end()) {
            Node_HT[curr_node->getPort()->getName()].fanOut.push_back(gate);
        } else {
            Node_HT[curr_node->getPort()->getName()] = Net(curr_node->getPort()->getName(), curr_node, nullptr, 
                                                                   {gate}, false, true);
        }
    };

    // Iterate through all gates in the inst_HT
    for (auto& it_ght : inst_HT) {
        map<string, hcmInstPort*> instPorts = it_ght.second.inst->getInstPorts();
        
        // Iterate through all the instance ports of the current gate
        for (auto& it_ip : instPorts) {
            hcmNode* curr_node = it_ip.second->getNode();
            auto& gate = it_ght.second;

            // Check direction of the port (IN/OUT)
            if (it_ip.second->getPort()->getDirection() == IN) {
                // Handle input ports
                if (curr_node->getPort() == nullptr) { // Non-global node
                    initialize_non_global_net(curr_node, &gate);
                } else { // Global node
                    initialize_global_net(curr_node, &gate);
                }
                // Add to inputNets
                gate.inputNets.push_back(&Node_HT[curr_node->getPort() ? curr_node->getPort()->getName() : curr_node->getName()]);
            } else if (it_ip.second->getPort()->getDirection() == OUT) {
                // Handle output ports
                if (curr_node->getPort() == nullptr) { // Non-global node
                    auto iter_net = Node_HT.find(curr_node->getName());
                    if (iter_net != Node_HT.end()) {
                        Node_HT[curr_node->getName()].input = &gate;
                    } else {
                        Node_HT[curr_node->getName()] = Net(curr_node->getName(), curr_node, &gate, {}, false, true);
                    }
                    gate.outputNet = &Node_HT[curr_node->getName()];
                } else { // Global node
                    auto iter_net = Node_HT.find(curr_node->getPort()->getName());
                    if (iter_net != Node_HT.end()) {
                        Node_HT[curr_node->getPort()->getName()].input = &gate;
                    } else {
                        Node_HT[curr_node->getPort()->getName()] = Net(curr_node->getPort()->getName(), curr_node, &gate, {}, false, true);
                    }
                    gate.outputNet = &Node_HT[curr_node->getPort()->getName()];
                }
            }
        }
    }
}
